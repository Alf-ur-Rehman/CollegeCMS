<?php
session_start();  // Developed by Olanrewaju (D Programmer)
session_destroy();
header("Location: index.php");
?>