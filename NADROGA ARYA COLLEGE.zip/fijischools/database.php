<?php
$cn=mysql_connect("localhost","ourfurni_fijiuser","08023164184Jamiu$$") or die("Could not Connect My Sql");
mysql_select_db("ourfurni_fijidb",$cn)  or die("Could connect to Database");
?>