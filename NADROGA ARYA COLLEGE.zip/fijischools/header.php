<head>


<!--- <link rel="icon" href="images/chmsc.png" type="image" />


 -->

<title>jjj</title>
    
	 
	
	    <link rel="stylesheet" type="text/css" href="css/bootstrap-progressbar.css">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
		
	
	
		<style type="text/css">
        .progress .bar.six-sec-ease-in-out {
            -webkit-transition: width 6s ease-in-out;
            -moz-transition: width 6s ease-in-out;
            -ms-transition: width 6s ease-in-out;
            -o-transition: width 6s ease-in-out;
            transition: width 6s ease-in-out;
        }
        .progress.vertical .bar.six-sec-ease-in-out {
            -webkit-transition: height 6s ease-in-out;
            -moz-transition: height 6s ease-in-out;
            -ms-transition: height 6s ease-in-out;
            -o-transition: height 6s ease-in-out;
            transition: height 6s ease-in-out;
        }
        .progress.wide {
            width: 60px;
        }
        .vertical-progressbar-span {
            height: 100px;
        }
    </style>


		
  
	

</head>
<script src="js/bootstrap.js" type="text/javascript"></script>
	<script src="js/jquery.js" type="text/javascript"></script>
	
	
	<script type="text/javascript" src="js/bootstrap-transition.js"></script>
	<script type="text/javascript" src="js/bootstrap-collapse.js"></script>
	<script type="text/javascript" src="js/bootstrap-tab.js"></script>
	<script type="text/javascript" src="js/bootstrap-progressbar.js"></script>
	<script src="js/bootstrap-carousel.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/bootstrap-alert.js"></script> 
	
	    <script>
        $(document).ready(function() {
		
               
                $('.progress .bar.text-filled-1').progressbar({
                    display_text: 1,
					         refresh_speed: 200,
                   transition_delay: 500,
             
            });
            
            });
   
    </script>	
  