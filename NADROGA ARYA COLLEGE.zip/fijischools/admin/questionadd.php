<?php
session_start();
require("../database.php");
error_reporting(1);
$admin = $_SESSION['SESS_MEMBER_ADMIN'];
if (!$admin){
header("location:../index.php");
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Administrative Page</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" />
<style type="text/css">
table tr td a{text-decoration:none;}
table tr td a:hover{text-decoration:underline; color:blue;}
input, select{font-size:16px;}

</style>
</head>
<body>
<div id="header">
	<div id="logo">
		<h1><a href="#" style="font-family:impact; font-size:27px;">2021/2022 EXAM</a></h1>
		<h2><a href="#" style="font-size:13px;">NADROGA ARYA COLLEGE</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li class="first"><a style="font-size:15px; color:blue;" href="admin.php" title=""><---Back</a></li>
				</ul>
	</div>
	<div id="ad468x60"><a href="#"><img src="images/ad468x60.jpg" alt="" width="468" height="60" /></a></div>
</div>
<div id="page">
	<div id="content">
		<div class="boxed" style="font-size:20px;">
			<h1 class="heading" style="font-size:18px;">Welcome...You are....<span style="color:red;"><?php echo $admin; ?></span></h1>
			
			
			
			 <?php
extract($_POST);



echo "<h3 class=head1></h3>";
if($_POST[submit]=='Save' || strlen($_POST['testid'])>0 )
{
extract($_POST);
mysql_query("insert into question(test_id,que_desc,studentid,ans1,ans2,ans3,ans4,true_ans) values ('$testid','$addque','$studentid','$ans1','$ans2','$ans3','$ans4','$anstrue')",$cn) or die(mysql_error());
echo "<p align=center>Question Added Successfully.</p>";
unset($_POST);
}
?>
<SCRIPT LANGUAGE="JavaScript">
function check() {
mt=document.form1.addque.value;
if (mt.length<1) {
alert("Please Enter Question");
document.form1.addque.focus();
return false;
}
a11=document.form1.studentid.value;
if(a11.length<1) {
alert("Please Enter Student ID for easy assessment and separation of Questions");
document.form1.studentid.focus();
return false;
}
a1=document.form1.ans1.value;
if(a1.length<1) {
alert("Please Enter Answer1");
document.form1.ans1.focus();
return false;
}
a2=document.form1.ans2.value;
if(a1.length<1) {
alert("Please Enter Answer2");
document.form1.ans2.focus();
return false;
}
a3=document.form1.ans3.value;
if(a3.length<1) {
alert("Please Enter Answer3");
document.form1.ans3.focus();
return false;
}
a4=document.form1.ans4.value;
if(a4.length<1) {
alert("Please Enter Answer4");
document.form1.ans4.focus();
return false;
}
at=document.form1.anstrue.value;
if(at.length<1) {
alert("Please Enter True Answer");
document.form1.anstrue.focus();
return false;
}
return true;
}
</script>

<div style="margin:auto;width:95%;height:auto;box-shadow:3px 3px 3px 6px #CCCCCC;text-align:left; margin-top:10px;"><br>
<center><b style="color:black; font-size:25px; text-align:center">Add PUTME Questions</b><br>

<form name="form1" method="post" onSubmit="return check();">
  <table width="95%"  border="0" align="center">
    <tr>
      <td width="45%" height="32"><div align="left"><strong>Select Test Name </strong></div></td>
      <td width="1%" height="5">  
      <td width="45%" height="32"><select style="width:100%; height:30px;" name="testid" id="testid">
<?php
$rs=mysql_query("Select * from mst_test order by test_name",$cn);
	  while($row=mysql_fetch_array($rs))
{
if($row[0]==$testid)
{
echo "<option value='$row[0]' selected>$row[2]</option>";
}
else
{
echo "<option value='$row[0]'>$row[2]</option>";
}
}
?>
      </select>
        </td></tr>
		
		  <tr>
      <td height="26"><div align="left"><strong>Enter Student ID </strong></div></td>
      <td>&nbsp;</td>
      <td><input style="width:100%; height:25px;" name="studentid" type="text" id="studentid" maxlength="45"></td>
    </tr>
	
    <tr>
        <td height="26" width="45%"><div align="left"><strong> Enter Question </strong></div></td>
        <td>&nbsp;</td>
	    <td><textarea style="width:100%; height:60px;" name="addque" cols="32" rows="2" id="addque"></textarea></td>
    </tr>
    <tr>
      <td height="26"><div align="left"><strong>Enter Answer1 </strong></div></td>
      <td>&nbsp;</td>
      <td><input style="width:100%; height:25px;" name="ans1" type="text" id="ans1"  maxlength="45"></td>
    </tr>
    <tr>
      <td height="26"><div align="left"><strong>Enter Answer2 </strong></div></td>
      <td>&nbsp;</td>
      <td><input style="width:100%; height:25px;"  name="ans2" type="text" id="ans2" maxlength="45"></td>
    </tr>
    <tr>
      <td height="26"><div align="left"><strong>Enter Answer3 </strong></div></td>
      <td>&nbsp;</td>
      <td><input style="width:100%; height:25px;" name="ans3" type="text" id="ans3"  maxlength="45"></td>
    </tr>
    <tr>
      <td height="26"><div align="left"><strong>Enter Answer4</strong></div></td>
      <td>&nbsp;</td>
      <td><input style="width:100%; height:25px;" name="ans4" type="text" id="ans4"  maxlength="45"></td>
    </tr>
    <tr>
      <td height="26"><div align="left"><strong>Enter True Answer </strong></div></td>
      <td>&nbsp;</td>
      <td><input style="width:100%; height:25px;" name="anstrue" type="text" id="anstrue"  maxlength="45"></td>
    </tr>
    <tr>
      <td height="26"></td>
      <td>&nbsp;</td>
      <td><input style="width:100px; height:30px;" type="submit" name="submit" value="Add" ></td>
    </tr>
  </table>
</form></center>
<p>&nbsp; </p>
</div>
  
  
 




		</div>
	</div>
	<!-- end #content -->
	<div id="sidebar">
		<div class="boxed">
			<h2 class="heading" style="font-size:15px;">ADMINISTRATIVE SECTION</h2>
			<div class="content" style="font-size:18px;">
				You are...<span style="color:black; font-weight:bold;"><?php echo $admin; ?></span><hr /><br />
				
				<span style="font-size:15px; color:black;"><b>SUGGESTED QUESTION(S)</b><br /></span>
				<span style="font-size:15px; color:black;">
				
				<b style="text-decoration:underline;">Science Class</b><br />
				
				<?php
				$top1 = $_GET['more1'];
				if ($top1){
				echo '<fieldset style="font-size:12px; padding:3px"><legend style="font-weight:bold"><b>Read More</b></legend>';
				echo '<span style="color:blue;">';
				
				$rs2=mysql_query("Select * from suggest WHERE class='science' and id=$top1");
				 while($row2=mysql_fetch_array($rs2)){
				 echo $q_es = $row2['question'];
				 } echo '	 </span></fieldset>';
				 }
				
				 ?>
			
				<span style="font-size:13px"><?php
				$rs11=mysql_query("Select * from suggest WHERE class='science'");
				
				if (mysql_num_rows($rs11) == 0){
				echo '<i>No Suggested Question(s) yet for this Class</i><br><br>';
				}else{
			  while($row11=mysql_fetch_array($rs11))
				{
				 $q_id = $row11['id'];
				 $questi = $row11['question'];
				 ?>
				<?php 
				if (strlen($questi)>30){
				echo substr($questi, 0, 10).'...';?> <a href="questionadd.php?more1=<?php echo $q_id; ?>"><span style="color:blue;">More</span> </a>
				<a style="text-decoration:none" href="qdel.php?id=<?php echo $q_id; ?>" title="Click To Delete"><span style="color:red;">**</span></a><hr />
				<?php
				}else{
				echo $questi.'<hr>';
				}
				}
				
				
				}
				?>
				</span>
				
				
				<b style="text-decoration:underline">Art Class</b><br />
		<?php
				$top2 = $_GET['more2'];
				if ($top2){
				echo '<fieldset style="font-size:12px; padding:3px"><legend style="font-weight:bold"><b>Read More</b></legend>';
				echo '<span style="color:blue;">';
				
				$rs2=mysql_query("Select * from suggest WHERE class='art' and id=$top2");
				 while($row2=mysql_fetch_array($rs2)){
				 echo $q_es = $row2['question'];
				 }echo 		' </span>				</fieldset>';
				}
				 ?>
		
				
				
				<span style="font-size:13px"><?php
				$rs11=mysql_query("Select * from suggest WHERE class='art'");
				
				if (mysql_num_rows($rs11) == 0){
				echo '<i>No Suggested Question(s) yet for this Class</i><br><br>';
				}else{
			  while($row11=mysql_fetch_array($rs11))
				{
				 $q_id = $row11['id'];
				 $questi = $row11['question'];
				 ?>
				<?php 
				if (strlen($questi)>30){
				echo substr($questi, 0, 10).'...';?> <a href="questionadd.php?more2=<?php echo $q_id; ?>"><span style="color:blue;">More</span> </a>
				<a style="text-decoration:none" href="qdel.php?id=<?php echo $q_id; ?>" title="Click To Delete"><span style="color:red;">**</span></a><hr />
				<?php
				}else{
				echo $questi.'<hr>';
				}
				}
				
				
				}
				?>
				</span>
				
				<b style="text-decoration:underline">Commercial Class</b><br />
			<?php
				$top = $_GET['more'];
				if ($top){
				echo '<fieldset style="font-size:12px; padding:3px"><legend style="font-weight:bold"><b>Read More</b></legend>';
				echo '<span style="color:blue;">';
				$rs2=mysql_query("Select * from suggest WHERE class='commercial' and id=$top");
				 while($row2=mysql_fetch_array($rs2)){
				 echo $q_es = $row2['question'];
				 }echo '	 </span>				</fieldset>';
				 }
				 ?>
			
				
				
				<span style="font-size:13px"><?php
				$rs112=mysql_query("Select * from suggest WHERE class='commercial'");
				
				if (mysql_num_rows($rs112) == 0){
				echo '<i>No Suggested Question(s) yet for this Class</i><br><br>';
				}else{
			  while($row11=mysql_fetch_array($rs112))
				{
				 $q_id = $row11['id'];
				 $questi = $row11['question'];
				 ?>
				<?php 
				if (strlen($questi)>30){
				echo substr($questi, 0, 10).'...';?> <a href="questionadd.php?more=<?php echo $q_id; ?>"><span style="color:blue;">More</span> </a>
				<a style="text-decoration:none" href="qdel.php?id=<?php echo $q_id; ?>" title="Click To Delete"><span style="color:red;">**</span></a><hr />
				<?php
				}else{
				echo $questi.'<hr>';
				}
				}
				
				
				}
				?>
				</span>
				
				
				</span>
				
			</div>
		</div>
	</div>
	<!-- end #sidebar -->
</div>
<!-- end #page -->
<div style="clear: both;">&nbsp;</div>
<div id="footer">
	<p id="legal" style="font-size:16px;">Copyright &copy; <?php echo date ('Y');?> NADROGA ARYA COLLEGE </p>
	<p id="links" style="font-size:16px;"><a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>
</div>
</body>
</html>
