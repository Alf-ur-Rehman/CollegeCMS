<?php
session_start();
require("../database.php");
error_reporting(1);
$admin = $_SESSION['SESS_MEMBER_ADMIN'];
if (!$admin){
header("location:../index.php");
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Administrative Page</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" />
<style type="text/css">
table tr td a{text-decoration:none; color:#0066FF;}
table tr td a:hover{text-decoration:underline; color:blue;}
table{color:black;}
.pr a{color:blue; text-decoration:none;}
.pr a:hover{text-decoration:underline; color:#000099;}
table tr th{background-color:black; color:white;}

.tot{widows:100$; height:auto; text-align:center; padding:2px; border:1px solid none; box-shadow:4px 6px 40px black; }
.now{font-size:70px; text-align:center; font-weight:bold;}

.tot1{widows:100$; height:auto; text-align:center; padding:2px; border:1px solid none; box-shadow:4px 6px 40px black; }
.now1{font-size:70px; text-align:center; font-weight:bold;}


</style>
</head>
<body>
<div id="header">
	<div id="logo">
		<h1><a href="#" style="font-family:impact; font-size:27px;">2021/2022 Exam</a></h1>
		<h2><a href="#" style="font-size:13px;">NADROGA ARYA COLLEGE</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li class="first"><a style="font-size:15px; color:blue;" href="admin.php" title=""><---Back</a></li>
				</ul>
	</div>
	<div id="ad468x60"><a href="#"><img src="images/ad468x60.jpg" alt="" width="468" height="60" /></a></div>
</div>
<div id="page">
	<div id="content">
		<div class="boxed" style="font-size:20px;">
			<h1 class="heading" style="font-size:18px;">Welcome...You are....<span style="color:red;"><?php echo $admin; ?></span></h1>
			
		
			
			
			
			<div class="pr" align="right"><a href="javascript:window.print()">Print Generated Pins</a></div>
			
			
<div style="margin:auto;width:90%;height:auto;box-shadow:3px 3px 3px 6px #CCCCCC;text-align:left; margin-top:10px; padding:10px;">
<span style="font-size:19px; color:black;">LIST OF <span style="color:RED;">UNUSED</span> REGISTRATION PINS <b>(For Sale)</b></span>

<?php
 $sql=mysql_query("SELECT * FROM regcode WHERE status = 'unused'");
						$rol = mysql_num_rows($sql);
						echo '<table style="text-align:center" border="1px" width="100%" cellpadding="5px" cellspacing="0px">';
						echo '<tr class="tabler"><th>S/N</th><th>PIN</th><th>Status</th><th>Action</th></tr>';
					while($appost=mysql_fetch_assoc($sql))
					{
					    $id = $appost['id'];
						 $code = $appost['code'];
						  $status = $appost['status'];
						   
						echo '<tr class="tabler1"><td>'.$id.'</td><td>'.$code.' </td><td>'.$status.'</td><td><a href="delport.php?id='.$appost['id'].'" class="delbutton" title="Click To Delete">Delete</a></td></tr>';
          
					}
		  
		  
		  echo '		  
		  </table>      ';
	  
	   
	   ?> 
       
     <br />
	 <span style="font-size:19px; color:black;">LIST OF <span style="color:blue;">USED</span> REGISTRATION PINS <b>(Already Sold)</b></span>
	 <?php
 $sql=mysql_query("SELECT * FROM regcode WHERE status = 'used'");
						$rol = mysql_num_rows($sql);
						echo '<table style="text-align:center" border="1px" width="100%" cellpadding="5px" cellspacing="0px">';
						echo '<tr class="tabler"><th>S/N</th><th>PIN</th><th>Status</th><th>Action</th></tr>';
					while($appost=mysql_fetch_assoc($sql))
					{
					    $id = $appost['id'];
						 $code = $appost['code'];
						  $status = $appost['status'];
						   
						echo '<tr class="tabler1"><td>'.$id.'</td><td>'.$code.' </td><td>'.$status.'</td><td><a href="delport.php?id='.$appost['id'].'" class="delbutton" title="Click To Delete">Delete</a></td></tr>';
          
					}
		  
		  
		  echo '		  
		  </table>      ';
	  
	   
	   ?> 
       
     



</div>
 




		</div>
	</div>
	<!-- end #content -->
	<div id="sidebar">
		<div class="boxed">
			<h2 class="heading" style="font-size:15px;">ADMINISTRATIVE SECTION</h2>
			<div class="content" style="font-size:18px;">
				You are...<span style="color:black; font-weight:bold;"><?php echo $admin; ?></span>
				<BR /><BR />
					<div class="tot">
					<span style="font-size:20px; color:black; font-weight:bold; text-decoration:underline; ">Unused Pins</span>
					<div class="now"><?php  $sql=mysql_query("SELECT * FROM regcode WHERE status = 'unused'");
						echo $rol = mysql_num_rows($sql);
						
						?></div></div>
					<BR /><BR />
						<div class="tot1">	<span style="font-size:20px; color:black; font-weight:bold; text-decoration:underline; ">Used Pins</span>
					<div class="now1"><?php  $sql=mysql_query("SELECT * FROM regcode WHERE status = 'used'");
						echo $rol = mysql_num_rows($sql);
						
						?></div></div>
				
				
			</div>
		</div>
	</div>
	<!-- end #sidebar -->
</div>
<!-- end #page -->
<div style="clear: both;">&nbsp;</div>
<div id="footer">
	<p id="legal" style="font-size:16px;">Copyright &copy; <?php echo date ('Y');?> NADROGA ARYA COLLEGE Portal</p>
	<p id="links" style="font-size:16px;"><a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>
</div>
</body>
</html>
