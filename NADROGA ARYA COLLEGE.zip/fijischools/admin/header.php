<head>
<?php
include('../database.php');
?>

<!--- <link rel="icon" href="images/chmsc.png" type="image" />


 -->

<title>NADROGA ARYA COLLEGE Admin Page...Activate Students</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 
	<link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
	 <link href="themes/5/js-image-slider.css" rel="stylesheet" type="text/css" />
    <link href="generic.css" rel="stylesheet" type="text/css" />

	    <link rel="stylesheet" type="text/css" href="css/bootstrap-progressbar.css">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
	<link rel="stylesheet" href="/css/font-awesome.min.css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="screen">
	<link href="css/bootstrap-responsive.css" rel="stylesheet" type="text/css" media="screen">
	<link href="css/jumbotron.css" rel="stylesheet" type="text/css" media="screen">
	<link href="css/navbar-fixed-top.css" rel="stylesheet" type="text/css" media="screen">
	  <link href="css/datePicker.css" media="screen" rel="stylesheet" type="text/css" />
	  
		
	
	
		<style type="text/css">
        .progress .bar.six-sec-ease-in-out {
            -webkit-transition: width 6s ease-in-out;
            -moz-transition: width 6s ease-in-out;
            -ms-transition: width 6s ease-in-out;
            -o-transition: width 6s ease-in-out;
            transition: width 6s ease-in-out;
        }
        .progress.vertical .bar.six-sec-ease-in-out {
            -webkit-transition: height 6s ease-in-out;
            -moz-transition: height 6s ease-in-out;
            -ms-transition: height 6s ease-in-out;
            -o-transition: height 6s ease-in-out;
            transition: height 6s ease-in-out;
        }
        .progress.wide {
            width: 60px;
        }
        .vertical-progressbar-span {
            height: 100px;
        }
    </style>


		
  
	

</head>
<script src="js/bootstrap.js" type="text/javascript"></script>
	<script src="js/jquery.js" type="text/javascript"></script>
	
	
	<script type="text/javascript" src="js/jquery.datePicker.js"></script>
	<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/bootstrap-transition.js"></script>
	<script type="text/javascript" src="js/bootstrap-collapse.js"></script>
	<script type="text/javascript" src="js/bootstrap-tab.js"></script>
	<script type="text/javascript" src="js/bootstrap-progressbar.js"></script>
	<script src="js/bootstrap-carousel.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/bootstrap-alert.js"></script> 
	<script type="text/javascript" src="js/search.js"></script> 
    <script src="themes/5/js-image-slider.js" type="text/javascript"></script>

	    <script>
        $(document).ready(function() {
		
               
                $('.progress .bar.text-filled-1').progressbar({
                    display_text: 1,
					         refresh_speed: 200,
                   transition_delay: 500,
             
            });
            
            });
   
    </script>	
  