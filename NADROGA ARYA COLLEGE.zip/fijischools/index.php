<?php
session_start();
	
	//Connect to mysql server
	require "database.php";
	
	//Function to sanitize values received from the form. Prevents SQL injection
	if (isset($_POST['regsubmit'])){
		$reg = $_POST['reg'];
	
		
	//Create query
	$qry="SELECT * FROM regcode WHERE code='$reg' AND status='unused'";
	$result=mysql_query($qry);
	
	//Check whether the query was successful or not
	if($result) {
		if(mysql_num_rows($result) > 0) {
			//Login Successful
			session_regenerate_id();
			$reg = mysql_fetch_assoc($result);
			$_SESSION['SESS_CODE_ID'] = $reg['id'];
			$_SESSION['SESS_CODE_NAME'] = $reg['code'];

			session_write_close();
			//if ($level="admin"){
			header("location: registration/register.php");
		}else {
			//Login failed
	
		$qryr=mysql_query("SELECT * FROM regcode WHERE code='$reg'");
		$rwr=mysql_fetch_assoc($qryr);
		if ($rwr['status']=="used"){
			
				echo '<script type="text/javascript">
alert("The PIN you entered has already be USED");
</script>';
		}else{
			
				echo '<script type="text/javascript">
alert("The PIN you entered is wrong or does not exist. Kindly re-check your Stratch Card and try again later");
</script>';
				
			
		}
	}
	}
	}
?>
<?php
include 'takelog.php';
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>FIJI Examination Portal</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="style1.css" rel="stylesheet" type="text/css" />
<link href="css/st.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
 <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/jquery.easing.min.js"></script>
  <script type="text/javascript" src="js/jquery.nivo.slider.pack.js"></script>
  
  <script src="js1/application.js" type="text/javascript" charset="utf-8"></script>	
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="src/facebox.js" type="text/javascript"></script>

  
  <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
  </script>

<script type="text/javascript">
jQuery(document).ready(function($) {
$('a[rel*=facebox]').facebox({
loadingImage : 'src/loading.gif',
closeImage   : 'src/closelabel.png'
})
})
</script>

</head>
<body>
<div id="bg1">
		
		<div class="poly" >
		<div class="hr1" style="text-transform:capitalize"><span style="font-size:30px; font-family:Bleeding Cowboys; color:white; "><span style="font-size:45px"><br />N</span>adroga <span style="font-size:45px">A</span>rya <span style="font-size:45px; " >C</span>ollege, <span style="font-size:45px">F</span>iji</span>
		<span style="font-family:Bradley Hand ITC; font-size:28px; color:grey;"><br />Main School Portal</span><br /><br />
	</div>
	</div>
	
	<div class="ad">Admin Section
	<form method="post" action="admin/adminlogin.php">
	<table style="color:white; font-family:tahoma; font-size:15px;" border="0px" cellpadding="0px" cellspacing="0px"><tr><td>Username</td><td>Password</td></tr>
	
	<tr><td><input type="username" name="username" required/></td><td><input type="password" name="password" required /></td>
	<br/>
	<td><div style="ad2"><input type="submit" name="adminsubmit" value="Login" /></div></td></tr>
	
	</table>
	</form>
	</div>
	
	
</div>

<div id="bg2">
	<div id="header2">
		<div id="menu">
			<ul style="text-transform:capitalize">
				<li><a href="index.php">Home</a></li>
				<li><a rel="facebox" href="regall.php" style="color:red;"><span style="font-size:22px; color:white;">*</span>Check EXAM Status</a></li>
				<li><a rel="facebox" href="cont.php">Contact</a></li>
				<li><a href="squestion.php">Suggest Questions</a></li>
			</ul>
		</div>
		<!-- end #menu -->
		<div id="search">
			<form method="get" action="#">
				<fieldset>
				<input type="text" name="q" value="search keywords" id="q" class="text" />
				<input type="submit" value="Search" class="button" />
				</fieldset>
			</form>
		</div>
		<!-- end #search -->
	</div>
	<!-- end #header2 -->
</div>
<!-- end #bg2 -->
<div id="bg3">
	<div id="bg4">
		<div id="bg5">
			<div id="page">
				<div id="content">
					<div class="post">
					
					    
					<div id="slider" class="nivoSlider">
            <img src="images/home_1.jpg" height="300px" width="10px" alt="" />
            <img src="images/home_2.jpg" height="300px" width="10px" alt="" />
            <img src="images/header_images.jpg" width="100x" alt="" />
		  </div>	
						
						
						
						<div class="entry"> <img src="images/img01.jpg" alt="" width="150" height="102" class="left" />
							<span style="font-size:22px; color:white; font-weight:bold">ABOUT NADROGA ARYA COLLEGE</span></br> <p style="font-size:14px; text-align:justify;" >Nadroga Arya College is the newest of the six secondary schools owned and managed by the Sabha. It was inaugurated in 1998 to bring secondary education to the rural people of Nadroga. The College has made a tremendous impact in the lives of the people of rural Nadroga under the leadership of a very experienced and dedicated Principal Mr. Kumar Shakil Chand. The College is a medium multiracial rural secondary school, offering secondary education up to Form 7. The efforts of Late Pta. Ram Kumari Bhushan ‘Arya Ratna’ and Mr. Moti Ram are given special recognition in this project..</p>
						</div>
				
					</div>
					<div class="post">
						<div class="title">
							<h2 style=" font-size:20px; color:white; text-transform:capitalize;">VISION</h2>
							<p>10.11.08</p>
						</div>
						<div class="entry" style="text-align:justify;">
							<p style="font-size:14px;">The vision of NAC in Fiji is to evolve "A society where everyone is literate and conforms to acceptable moral, spiritual, cultural and social values.</p>
						</div>
					
					</div>
					
				<div class="post">
						<div class="title">
							<h2 style=" font-size:20px; color:white; text-transform:capitalize;">MISSION</h2>
							<p>10.11.08</p>
						</div>
						<div class="entry" style="text-align:justify;">
							<p style="font-size:14px;">The Mission Statement of NAC is to provide learning opportunities to all through:
							- A conducive environment
							- Innovative values education
							- Life skills (Vocational Training)
							- Appropriate curricular and resources for physical, cultural, mental and spiritual development
							- Lifelong learning/</p>
						</div>
					
					</div>	
					
					
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2 style="text-transform:capitalize; font-size:17px;">Registration Section</h2>
							<p style="font-size:17px; color:white;"><span style="font-size:20px;">*</span><a href="index.php?idex=apply" style="color:red; text-decoration:none;">Apply Now</a><br />
						
							<?php
				   $none = "none";
				   $_GET['idex'];
				   $admin = $_GET['idex'];
				   if ($admin){
					   echo '			
							
								<form method="post" action="index.php">
	<table style="color:white; font-family:tahoma; font-size:15px;" border="0px" cellpadding="0px" cellspacing="0px"><tr><td>Put Your Pin</td></tr>
	<tr><td><input type="text" name="reg" required /></td><td><div style="ad2"><input style="width:65px; height:25px;" type="submit" name="regsubmit" value="Proceed" /></div></td></tr>
	
	</table>
	</form><br>
							<a href="index.php">Exit</a>';
							}
							?>
							</p>
							<p style="font-size:16px; "><span style="font-size:20px; color:white;">*</span><a href="index.php?ide1=reprint" style="color:grey; text-decoration:none;">Re-print Photo Card</a>
							
										<?php
				   $none = "none";
				   $_GET['ide1'];
				   $admin1 = $_GET['ide1'];
				   if ($admin1){
					   echo '			
							
								<form method="post" action="reprint.php">
	<table style="color:white; font-family:tahoma; font-size:15px;" border="0px" cellpadding="0px" cellspacing="0px"><tr><td>Put Your EXAM No</td></tr>
	<tr><td><input type="text" name="utme" required /></td><td><div style="ad2"><input style="width:65px; height:25px;" type="submit" name="utmesubmit" value="Print Slip" /></div></td></tr>
	
	</table>
	</form><br>
							<a href="index.php">Exit</a>';
							}
							?>
							
							</p>
							</li>
							
							<li>
							<h2 style="text-transform:capitalize; font-size:17px;">Exam Section </h2>
							<p style="font-size:17px; color:red;"><span style="font-size:20px;">*</span><a href="index.php?ide2=take" style="color:white; text-decoration:none;">Take Exam </a>
							
							
							<?php
				   $none = "none";
				   $_GET['ide2'];
				   $admin2 = $_GET['ide2'];
				   if ($admin2){
					   echo '			
							
								<form method="post" action="index.php">
	<table style="color:white; font-family:tahoma; font-size:15px;" border="0px" cellpadding="0px" cellspacing="0px"><tr><td>Put Your EXAM No</td></tr>
	<tr><td><input type="text" name="take" /></td><td><div style="ad2"><input style="width:65px; height:25px;" type="submit" name="takesubmit" value="Take" /></div></td></tr>
	
	</table>
	</form><br>
							<a href="index.php">Exit</a>';
							}
							?>
							
							
							
							
							
							</p>
							</li>
							
						<li>
							<h2 style="text-transform:capitalize; font-size:17px;">login Section</h2>
							<p style="font-size:16px; "><span style="font-size:20px; color:white;">*</span><a href="index.php?ide3=check" style="color:grey; text-decoration:none;">Check Result</a>
							<?php
				   $none = "none";
				   $_GET['ide3'];
				   $admin3 = $_GET['ide3'];
				   if ($admin3){
					   echo '			
							
								<form method="post" action="checker.php">
	<table style="color:white; font-family:tahoma; font-size:15px;" border="0px" cellpadding="0px" cellspacing="0px"><tr><td>Put Your EXAM No</td></tr>
	<tr><td><input type="text" name="check" required /></td><td><div style="ad2"><input style="width:65px; height:25px;" type="submit" name="checksubmit" value="Result" /></div></td></tr>
	
	</table>
	</form><br>
							<a href="index.php">Exit</a>';
							}
							?>
							
							</p>
							<p style="font-size:16px; "><span style="font-size:20px; color:white;">*</span><a href="index.php?ide4=status" style="color:grey; text-decoration:none;">Check Admission Status</a>
							
							<?php
				   $none = "none";
				   $_GET['ide4'];
				   $admin4 = $_GET['ide4'];
				   if ($admin4){
					   echo '			
							
								<form method="post" action="resultcheck.php">
	<table style="color:white; font-family:tahoma; font-size:15px;" border="0px" cellpadding="0px" cellspacing="0px"><tr><td>Put Your EXAM No</td></tr>
	<tr><td><input type="text" name="status" required /></td><td><div style="ad2"><input style="width:65px; height:25px;" type="submit" name="statussubmit" value="Status" /></div></td></tr>
	
	</table>
	</form><br>
							<a href="index.php">Exit</a>';
							}
							?>
							</p>
						
							
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both; height: 40px;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<!-- end #bg3 -->
<div id="footer">
	<p style="font-size:16px; text-transform:capitalize">(c)NADROGA ARYA COLLEGE Entrance Examination.</p>
</div>
<!-- end #footer -->
></body>
</html>
