<html><head>


 
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js1/application.js" type="text/javascript" charset="utf-8"></script>	
<script src="lib/jquery.js" type="text/javascript"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="src/facebox.js" type="text/javascript"></script>

<!--[if lt IE 9]>
<script type="text/javascript" src="js/ie6_script_other.js"></script>
<script type="text/javascript" src="js/html5.js"></script>

<![endif]-->
<style type="text/css">

 td{ padding:5px; border:1px solid black; color:black;}
table th{background-color:black; color:white; text-align:center;}
a{text-decoration:none; color:blue;}
a:hover{color: #0066FF;}
</style>
<script type="text/javascript">
jQuery(document).ready(function($) {
$('a[rel*=facebox]').facebox({
loadingImage : 'src/loading.gif',
closeImage   : 'src/closelabel.png'
})
})
</script>
</head><body>
<span style="color:black; font-size:20px; font-weight:bold;">LIST OF REGISTERED STUDENTS</span><br>
 
<?php 
require "database.php";
	$result= mysql_query("select * from studentreg")or die(mysql_error());
	echo '<table width="600px" border="0px" cellpadding="0px" cellspacing="0px">';
   echo ' <tr><th>Full Name</th><th>Gender</th><th>Jamb No</th><th>Photograph</th><th> Status</th></tr>';
	
	while($row=mysql_fetch_array($result)){
	$id=$row['id'];
echo '   <tr> <td style="width:150px">'.$row['surname'].' xxxxx</td>';
	echo '   <td><center>'. $row['gender'].'</center></td><td><center>****</center></td>';
echo '<td><center>To be shown upon status checking</center></td>';
   echo ' <td style="width:80px"><a rel="facebox" href="show.php?show='. $id.'" data-toggle="modal"><center>Check/Confirm Status</center></a></td><tr>';
 
	 } 
	 echo '</table>';
	 
	 ?>
</body>
</html>
      <a href="show.php?show= "